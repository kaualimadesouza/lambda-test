def log(message: str) -> None:
    print(f"Log: {message}")